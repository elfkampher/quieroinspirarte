

<?php $__env->startPush('styles'); ?>
<!-- daterange picker -->
<link rel="stylesheet" href="<?php echo e(asset('assets/adminlte/plugins/daterangepicker/daterangepicker.css')); ?>">
<!-- summernote -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/adminlte/plugins/summernote/summernote-bs4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/adminlte/plugins/select2/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.2/basic.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('header'); ?>
<div class="container-fluid">
	<div class="row mb-2">
	  <div class="col-sm-6">
	    <h3 class="m-0 text-dark">Crear Publicación</h3>
	  </div><!-- /.col -->
	  <div class="col-sm-6">
	    <ol class="breadcrumb float-sm-right">
	      <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Inicio</a></li>
	      <li class="breadcrumb-item"><a href="<?php echo e(url('admin/post/index')); ?>">Posts</a></li>
	      <li class="breadcrumb-item active">Crear</li>
	    </ol>
	  </div><!-- /.col -->
	</div><!-- /.row -->
</div><!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	

<?php
	$errores = "";
?>		
<div class="row">
	<div class="col-md-8">
		<div class="card card-primary">
		  <div class="card-header">
		    <h3 class="card-title">Edición de Post</h3>
		  </div>
		  <!-- /.card-header -->
		  <!-- form start -->
		  <form method="POST" action="<?php echo e(route('admin.posts.update', $post)); ?>">		
		  	<?php echo csrf_field(); ?>
		  	<?php echo e(method_field('PUT')); ?>

		    <div class="card-body">
		    
			  	<div class="form-group" >
			    	<label for="title">Titulo de la publicación</label>
			    	<input type="text" id="title" name="title" class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('title', $post->title)); ?>">
			  	</div>				  	
			  	
			  	<label>Contenido publicación</label>
			  	<div class="form-group">
			    	<textarea class="input-block-level <?php echo e($errors->has('body') ? 'is-invalid' : ''); ?>" id="body" name="body" rows="10"><?php echo e(old('body', $post->body)); ?></textarea>
			    	<?php echo $errors->first('body', '<span class="error invalid-feedback">:message</span>'); ?>

			  	</div>

			  	<div class="form-group <?php echo e($errors->has('iframe') ? 'is-invalid' : ''); ?>">
			  		<label>Contenido embebido (iframe)</label>
			  		<textarea rows="2" name="iframe" class="form-control" placeholder="Ingresa contenido embebido (iframe) de audio o video"><?php echo e(old('iframe', $post->iframe)); ?></textarea>
			  	</div>	

					<div class="row">
			  		<?php $__currentLoopData = $post->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			  			
				  		<div class="col-md-2">
				  			<a photo_id="<?php echo e($photo->id); ?>" class="btn btn-danger btn-xs deletephoto" style="position: absolute">
				  				<i class="fas fa-times"></i>
				  			</a>
				  			<img class="img-thumbnail" src="<?php echo e(url($photo->url)); ?>">
				  		</div>				  		
				  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  	</div>

		    </div>
		    <!-- /.card-body -->		    
		  
		</div>
	</div>

	<div class="col-md-4">
		<div class="card card-primary">
		  <div class="card-header">
		    <h3 class="card-title"></h3>
		  </div>
		  <!-- /.card-header -->
		  <div class="card-body">

		  	<div class="form-group">
				    	<label for="excerpt" >Extracto de la publicación</label>
				    	<textarea id="excerpt" name="excerpt" class="form-control <?php echo e($errors->has('excerpt') ? 'is-invalid' : ''); ?>" rows="2"><?php echo e(old('excerpt', $post->excerpt)); ?></textarea>
				    	<?php echo $errors->first('excerpt', '<span class="error invalid-feedback">:message</span>'); ?>

				  </div>		  	

			  	<div class="form-group">	                	
	          	<label>Date:</label>
	            
	        	<input type="text" class="form-control" name="published_at" id="published_at" value="<?php echo e(old('published_at', $post->published_at ? $post->published_at->format('m/d/Y'): null )); ?>" />	            
	        </div>

	        <div class="form-group">
	        	<label>Categorias</label>
	        	<select class="form-control select2 <?php echo e($errors->has('category_id') ? 'is-invalid' : ''); ?>" name="category_id" id="category_id">
	        		<option value="">Selecciona una categoria</option>
	        		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        		<option value="<?php echo e($category->id); ?>"
	        			<?php echo e(old('category_id', $post->category_id) == $category->id ? 'selected': ""); ?>

	        		><?php echo e($category->name); ?></option>
	        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	        	</select>
	        	<?php echo $errors->first('category_id', '<span class="error invalid-feedback">:message</span>'); ?>

	        </div>

	        <div class="form-group" >
	        	<label>Etiquetas</label>
	        	<select class="select2 form-control <?php echo e($errors->has('tags') ? 'is-invalid' : ''); ?>" 
	        	multiple="multiple" id="tags[]" name="tags[]" data-placeholder="Seleccione Etiquetas">
	        		<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        		<option value="<?php echo e($tag->id); ?>"
	        			<?php echo e(collect(old('tags', $post->tags->pluck('id')))->contains($tag->id) ? 'selected' : ''); ?>

	        		><?php echo e($tag->name); ?></option>
	        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	        	</select>
	        </div>

	        <div class="form-group">
			  		<div class="dropzone"></div>
			  	</div>

	        <div class="form-group">
	        	<button type="submit" class="btn btn-primary btn-block">Guardar Publicación</button>
	        </div>

	        </form>
		  </div>
		  <!-- /.card-body -->
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.2/min/dropzone.min.js"></script>
<!-- InputMask -->
<script src="<?php echo e(asset('assets/adminlte/plugins/moment/moment.min.js')); ?>"></script>
<!-- date-range-picker -->
<script src="<?php echo e(asset('assets/adminlte/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<!-- Summernote -->
<script src="<?php echo e(asset('assets/adminlte/plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<!-- Select2 -->
<script src="<?php echo e(asset('assets/adminlte/plugins/select2/js/select2.full.min.js')); ?>"></script>
<script>
//Date range picker
$(function() {
  $('input[name="published_at"]').daterangepicker({
    singleDatePicker: true,
    showDropdowns: true,
    autoUpdateInput: true
    
  });

  $('#body').summernote()

  $('.select2').select2({
  	tags: true
  })
});

var myDropzone = new Dropzone('.dropzone',{
   url: '/admin/posts/<?php echo e($post->url); ?>/photos',
   acceptedFiles: 'image/*',
   paramName: 'photo',
   maxFileSize: 2,
   maxFiles: 6,
   headers: {
      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
   },
   
   dictDefaultMessage: 'Arrastra las fotos aquí para subirlas'
});
 
Dropzone.autoDiscover = false;
 
myDropzone.on('error', function(file, res) {
   var msg = res.errors.photo[0];
   $('.dz-error-message:last > span').text(msg);
}); 

Dropzone.autoDiscover = false;

$(document).on('click', '.deletephoto', function(){
	var photo_id = $(this).attr('photo_id');

	$.ajax({
		url: "<?php echo e(url('admin/photos/deletephoto')); ?>",
		type: "post",		
		data:{			
			_token: '<?php echo e(csrf_token()); ?>',
			id: photo_id
		},
		success: function(){
			swal(
				"Listo!", 
				"La foto ha sido borrada", 
				"warning"
			).then(function(){
				location.reload();
			});			
		}
	});
});

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\blog\resources\views/admin/posts/edit.blade.php ENDPATH**/ ?>