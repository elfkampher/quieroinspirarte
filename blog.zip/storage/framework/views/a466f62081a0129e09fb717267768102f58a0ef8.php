
<!--         carousel  -->
<div class="section" id="carousel">
  <div class="container">
    <div class="row">
      <div class="col-md-8 mr-auto ml-auto">
        <!-- Carousel Card -->
        <div class="card card-raised card-carousel">
          <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" data-interval="3000">
            <ol class="carousel-indicators">
              <?php $__currentLoopData = $post->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li data-target="#carouselExampleIndicators" 
                data-slide-to="<?php echo e($loop->index); ?>" 
                class="<?php echo e($loop->first ? 'active': ''); ?>">                
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
            </ol>
            <div class="carousel-inner">

              <?php $__currentLoopData = $post->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                <img class="d-block w-100" src="<?php echo e(url($photo->url)); ?>" alt="<?php echo e($loop->index); ?>">
                <div class="carousel-caption d-none d-md-block">        
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
              <i class="material-icons">keyboard_arrow_left</i>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
              <i class="material-icons">keyboard_arrow_right</i>
              <span class="sr-only">Next</span>
            </a>
          </div>
        </div>
        <!-- End Carousel Card -->
      </div>
    </div>
  </div>
</div>
<!--         end carousel --><?php /**PATH D:\laragon\www\blog\resources\views/posts/carousel.blade.php ENDPATH**/ ?>