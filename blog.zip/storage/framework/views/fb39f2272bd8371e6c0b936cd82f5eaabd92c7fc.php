<section class="footer">
		<footer class="footer footer-default">
    <div class="container">
      <nav class="float-left">
        <ul>
          <li>
            <a href="/contacto">
              Contacto
            </a>
          </li>
          <li>
            <a href="/acerca-de">
              About Us
            </a>
          </li>
          <li>
            <a href="/">
              Blog
            </a>
          </li>
          <li>
            <a href="/license">
              Licenses
            </a>
          </li>
        </ul>
      </nav>
      <div class="copyright float-right">
        &copy;
        <script>
          document.write(new Date().getFullYear())
        </script>, Hecho con <i class="material-icons">favorite</i> Por
        <a href="https://www.encodyne.com.mx/" target="_blank">Encodyne</a> cybertechnology.
      </div>
    </div>
  </footer><?php /**PATH D:\laragon\www\blog\resources\views/partials/footer.blade.php ENDPATH**/ ?>