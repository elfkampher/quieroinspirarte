
<div class="modal fade" id="postModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST" action="<?php echo e(route('admin.posts.store', '#create')); ?>">
      <?php echo csrf_field(); ?>
      <div class="modal-header">
        <h4 class="modal-title">Agrega el titulo a la nueva publicación</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group" >
          
          <input type="text" id="title" name="title" class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('title')); ?>">
          <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="alert alert-danger">Es necesario ingresar el titulo</p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<?php /**PATH D:\laragon\www\blog\resources\views/admin/posts/create.blade.php ENDPATH**/ ?>