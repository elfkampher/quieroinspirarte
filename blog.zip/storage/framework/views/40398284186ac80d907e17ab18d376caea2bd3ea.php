    
<?php $__env->startSection('content'); ?>



<div class="main main-raised">
    <div class="profile-content">
        <div class="container">                            
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
            <article class="post col-md-12">            
                <?php if($post->photos->count() === 1): ?>
                    <figure><img src="<?php echo e($post->photos->first()->url); ?>" alt="" class="img-responsive"></figure>
                <?php elseif($post->photos->count() > 1): ?>

                    <div class="gallery-photos" data-masonry='{"itemSelector": ".grid-item", "columnWdith": 464}'>
                        <?php $__currentLoopData = $post->photos->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <figure class="grid-item grid-item--height2">
                                <?php if($loop->iteration === 4): ?>
                                    <div class="overlay"><?php echo e($post->photos->count()); ?> Fotos</div>
                                <?php endif; ?>
                                <img src="<?php echo e(url($photo->url)); ?>" class="img-responsive" alt="">
                            </figure>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php elseif($post->iframe): ?>
                    <div class="video">
                        <?php echo $post->iframe; ?>

                    </div>
                <?php endif; ?>

                    

                <div class="content-post">

                    <header class="container-flex space-between">
                        <div class="date">
                            <span class="c-gray-1"><?php echo e($post->published_at->diffForHumans()); ?></span>
                        </div>
                        <div class="post-category">
                            <span class="category text-capitalize">
                                <a href="<?php echo e(route('categories.show', $post->category)); ?>">
                                    <?php echo e($post->category->name); ?>

                                </a>
                            </span>
                        </div>
                    </header>
                    <h1><?php echo e($post->title); ?></h1>
                    <div class="divider"></div>
                    <p><?php echo e($post->excerpt); ?></p>
                    <footer class="container-flex space-between">
                        <div class="read-more">
                            <a href="blog/<?php echo e($post->url); ?>" class="text-uppercase c-green">Leer más</a>
                        </div>
                        <div class="tags container-flex">
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="tag c-gray-1 text-capitalize"><a href="<?php echo e(route('tags.show', $tag)); ?>">#<?php echo e($tag->name); ?></a></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </footer>
                </div>
            </article>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
    </div>
</div>
        


                
          

    <?php echo e($posts->links('vendor.pagination.default')); ?>

   
<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layoutct', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\blog\resources\views/welcome.blade.php ENDPATH**/ ?>