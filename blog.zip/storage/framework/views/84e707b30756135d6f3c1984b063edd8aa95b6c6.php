

<?php $__env->startSection('meta-title', $post->title); ?>
<?php $__env->startSection('meta-description', $post->excerpt); ?>

<?php $__env->startSection('content'); ?>

<div class="main main-raised">

    <?php if($post->photos->count() > 1): ?>
      <?php echo $__env->make('posts.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <div class="profile-content">
        <div class="container">                                  
          
                  <?php if($post->photos->count() === 1): ?>
                  <div class="profile">
                    <div class="avatar">
                      <figure><img src="<?php echo e($post->photos->first()->url); ?>" alt="" class="img-raised rounded-circle img-fluid"></figure>    
                    </div>
                  </div>
                  <?php elseif($post->iframe): ?>
                      <div class="video">
                          <?php echo $post->iframe; ?>

                      </div>
                  <?php endif; ?>
                  <div class="content-post">
                    <header class="container-flex space-between">
                      <div class="date">
                        <span class="c-gris"><?php echo e($post->published_at->format('M d')); ?></span>
                      </div>
                      <div class="container-category">
                        <span class="category"><?php echo e($post->category->name); ?></span>
                      </div>
                    </header>
                    
                    <h1><?php echo e($post->title); ?></h1>
                    <div class="divider"></div>
                    <div class="image-w-text">
                        <?php echo $post->body; ?>

                    </div>

                    <footer class="container-flex space-between">
                    <?php echo $__env->make('partials.social-links', ['description' => $post->title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                      <div class="tags container-flex">
                          <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="tag c-gris">#<?php echo e($tag->name); ?></span>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                    </footer>
                    <div class="comments">
                      <div class="divider"></div>
                        <div id="disqus_thread"></div>

                        <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>

                        <?php echo $__env->make('partials.disqus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                        
                    </div><!-- .comments -->
                  </div>
                
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/twitter-bootstrap.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>

<script id="dsq-count-scr" src="//zendero.disqus.com/count.js" async></script>
<script
  src="<?php echo e(asset('/assets/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/twitter-bootstrap.js')); ?>"></script> 

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layoutct', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\blog\resources\views/posts/show.blade.php ENDPATH**/ ?>