/**
 * A function get the intersection of two arrays. IE9+.
 */
export declare const intersection: (arr1: any[], arr2: any[]) => any[];
